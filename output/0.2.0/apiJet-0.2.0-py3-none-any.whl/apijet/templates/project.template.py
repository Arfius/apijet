# auto-generated code
import os
import json
info = json.loads(open(f"{os.getcwd()}/apijet.json", "r").read())
